-- This module is deprecated and must not be used.
-- This file serves as a tombstone to prevent old emails to be loaded

return